#ifndef RETICLE_H
#define RETICLE_H

#include <SDL.h>

/// @brief rendereli a c�lkeresztet a j�t�kban
/// @param renderer j�t�k rendererje
/// @param texture a c�lkereszt text�r�ja
void renderReticle(SDL_Renderer* renderer, SDL_Texture* texture);

#endif